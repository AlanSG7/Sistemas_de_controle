% DaqDuino Example:
% 1) Square wave response;
% 2) Least-squares identification;
% 3) Digital PID control;
clear all; close all; clc;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%(1)%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Creates an input vector u, e.g., step, square, sin functions
  u(1:20)=1; u(21:40)=2; u(41:60)=1; u(61:81)=2; % Square function
  nit = length(u); % number of iterations based on the length of u.

% Setting the sampling time to be used during  control and acquisition.
  Ts = 0.05; % 0.05 seconds is the recommended minimum value in order
             % to avoid sync errors between Matlab and DaqDuino.
  
% Connection between MATLAB, DaqDuino and the plant linked to the
% DaqDuino Dada Acquisition device.
daqduino_start('/dev/ttyUSB0'); % Starts DaqDuino board connected to COM5.
for k=1:nit,
  y(k) = daqduino_read; % single-shot acquisition.
    
  daqduino_write(u(k),Ts); % D/A to analog output, and delaying Ts seconds.
end
daqduino_end; % End the connection to the DaqDuino device.

% Ploting results
t=0:Ts:nit*Ts-Ts; % Time vector based on Ts.
subplot(211),
    plot(t,y,'b','linewidth',2);
    ylabel('Output y(t)');
subplot(212),
    plot(t,u,'r','linewidth',2);
    ylabel('Input u(t)'); xlabel('Time (s)');

    
    
    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%(2)%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
   
% Least Squares Identification
% Using a second-order model
    PHI = [ -y(1)   0      u(1)  0   ;
            -y(2)  -y(1)   u(2)  u(1)]; % Matrix of regressors
    Y = y'; % Vector of observations
    for k=3:nit,
        PHI = [PHI; [-y(k-1) -y(k-2)  u(k-1) u(k-2)] ];
    end
    theta = inv(PHI'*PHI)*PHI'*Y; % Parameters vector

% Identified model
  disp('Second-order discrete model parameters:')
  a1=theta(1), a2=theta(2), b0=theta(3), b1=theta(4),
  
  % Discrete-time transfer function
    num=[b0  b1  0 ];
    den=[ 1  a1  a2];
    disp('Discrete-time model identified:');
    Gz = tf(num,den,Ts)
    
  % Simulated output to the same input used in practice
    ysim=dlsim(num,den,u);
    % Ploting against real acquired data
      subplot(211), hold on;
        plot(t,ysim,'g'); legend('Real','Simulated');
        
% Continuous-time model based on discrete identified one
  disp('Continuous-time model obtained from the discrete one:');
  Gs = d2c(Gz,'zoh')


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%(3) DIGITAL PID CONTROL %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% PID tuning by "pole cancellation" and closed-loop time constant selection
    tau_mf = 1; % given in seconds
    zd = exp(-Ts/tau_mf); % desired closed-loop real discrete pole.

    s0= (1-zd)/(b0+b1);
    s1= s0*a1;
    s2= s0*a2;
    
% Applying the designed PID controller to the plant

% Generatins a reference sequence yr
  yr(1:10)=0; yr(11:nit)=1;
  clear u y ysim; % clearing I/O variables

daqduino_start('/dev/ttyUSB0');

% Setting up initial conditions
for k=1:2,
    y(k)=0; u(k)=0;
    e(k)=0; % error between the reference and the output
    
    ys(k)=0; us(k)=0; es(k)=0;
end
for k=3:nit,
    y(k)=daqduino_read;
    e(k) = yr(k)-y(k); % calculating the error
    
    % Control law:
    u(k)=u(k-1) +s0*e(k) +s1*e(k-1) +s2*e(k-2);
    daqduino_write(u(k),Ts);
    
    % Simulated test
    ys(k)= -a1*ys(k-1) -a2*ys(k-2) +b0*us(k-1) +b1*us(k-2);
    es(k)= yr(k)-ys(k);
    us(k)=us(k-1) +s0*es(k) +s1*es(k-1) +s2*es(k-2);
end
daqduino_end;

% Ploting results
figure(2); % opens a new figure window
subplot(211),
    plot(t,yr,':k',t,y,'b',t,ys,'r','linewidth',2);
    ylabel('Output y(t)');
    legend('y_r(t)','y(t)','y_s(t)');
subplot(212),
    plot(t,u,'b',t,us,'r','linewidth',2);
    ylabel('Control u(t)');
    legend('u(t)','u_s(t)');
    xlabel('Time (s)');

